from datetime import datetime

import pytest
from pyspark.sql import SparkSession

from streaming.transforms import add_metadata, invalid_events, valid_events


@pytest.fixture(scope="session")
def spark():
    session = SparkSession.builder.master("local[1]").appName("tests").getOrCreate()
    yield session
    session.stop()


def test_valid_and_invalid_events(spark):
    rows = [
        ("1", "page_view", "2026-01-01T10:00:00Z", "u1", "p1"),
        ("2", "page_view", "bad-date", "u2", "p2"),
        ("3", "page_view", "2026-01-01T10:00:00Z", None, "p3"),
    ]
    df = spark.createDataFrame(
        rows, ["event_id", "event_type", "event_timestamp", "user_id", "product_id"]
    )
    enriched = add_metadata(df, "test")
    assert valid_events(enriched).count() == 1
    assert invalid_events(enriched).count() == 2
    assert isinstance(valid_events(enriched).first().event_ts, datetime)
