import sys

from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import functions as F

args = getResolvedOptions(sys.argv, ["JOB_NAME", "SOURCE_BUCKET", "TARGET_BUCKET"])
glue = GlueContext(SparkContext.getOrCreate())
spark = glue.spark_session
job = Job(glue)
job.init(args["JOB_NAME"], args)

source = f"s3://{args['SOURCE_BUCKET']}/bronze"
target = f"s3://{args['TARGET_BUCKET']}"
clicks = spark.read.parquet(f"{source}/clickstream")
orders = spark.read.parquet(f"{source}/orders")
inventory = spark.read.parquet(f"{source}/inventory")

silver_clicks = clicks.select(
    "event_id",
    "event_ts",
    "event_date",
    "user_id",
    "session_id",
    "product_id",
    "event_type",
    "device_type",
    "referrer",
    "ingested_at",
).dropDuplicates(["event_id"])
silver_orders = (
    orders.withColumn("gross_amount", F.col("quantity") * F.col("unit_price"))
    .withColumn("net_amount", F.col("gross_amount") - F.coalesce("discount_amount", F.lit(0.0)))
    .select(
        "event_id",
        "event_ts",
        "event_date",
        "order_id",
        "user_id",
        "product_id",
        "quantity",
        "unit_price",
        "discount_amount",
        "gross_amount",
        "net_amount",
        "currency",
        "status",
        "shipping_country",
        "ingested_at",
    )
    .dropDuplicates(["event_id"])
)

silver_clicks.write.mode("overwrite").partitionBy("event_date").parquet(
    f"{target}/silver/clickstream"
)
silver_orders.write.mode("overwrite").partitionBy("event_date").parquet(f"{target}/silver/orders")
silver_inventory = inventory.select(
    "event_id",
    "event_ts",
    "event_date",
    "product_id",
    "warehouse_id",
    "quantity_on_hand",
    "units_reserved",
    "reorder_point",
    "ingested_at",
).dropDuplicates(["event_id"])
silver_inventory.write.mode("overwrite").partitionBy("event_date").parquet(
    f"{target}/silver/inventory"
)

daily_product = silver_orders.groupBy("event_date", "product_id").agg(
    F.countDistinct("order_id").alias("orders"),
    F.sum("quantity").alias("units_sold"),
    F.sum("gross_amount").alias("gross_revenue"),
    F.sum("net_amount").alias("net_revenue"),
    F.countDistinct("user_id").alias("unique_customers"),
)
customer_activity = silver_clicks.groupBy("event_date", "user_id").agg(
    F.count("event_id").alias("events"),
    F.countDistinct("session_id").alias("sessions"),
    F.sum(F.when(F.col("event_type") == "add_to_cart", 1).otherwise(0)).alias("add_to_carts"),
)
daily_product.write.mode("overwrite").partitionBy("event_date").parquet(
    f"{target}/gold/daily_product_performance"
)
customer_activity.write.mode("overwrite").partitionBy("event_date").parquet(
    f"{target}/gold/customer_activity"
)
inventory_trends = silver_inventory.groupBy("event_date", "product_id", "warehouse_id").agg(
    F.min("quantity_on_hand").alias("min_on_hand"),
    F.max("quantity_on_hand").alias("max_on_hand"),
    F.avg("quantity_on_hand").alias("avg_on_hand"),
    F.max("reorder_point").alias("reorder_point"),
    F.max(F.when(F.col("quantity_on_hand") <= F.col("reorder_point"), 1).otherwise(0)).alias(
        "low_stock_flag"
    ),
)
inventory_trends.write.mode("overwrite").partitionBy("event_date").parquet(
    f"{target}/gold/inventory_trends"
)
job.commit()
