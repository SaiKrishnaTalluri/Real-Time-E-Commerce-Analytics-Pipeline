"""Synthetic event producer."""
