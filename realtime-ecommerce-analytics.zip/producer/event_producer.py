import json
import os
import random
import signal
import time
import uuid
from datetime import UTC, datetime

from confluent_kafka import Producer
from faker import Faker

fake = Faker()
running = True
PRODUCTS = [
    ("P1001", "Wireless Headphones", "electronics", 89.99),
    ("P1002", "Running Shoes", "sports", 119.00),
    ("P1003", "Coffee Maker", "home", 74.50),
    ("P1004", "Backpack", "accessories", 54.99),
    ("P1005", "Smart Watch", "electronics", 199.00),
]


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def clickstream_event(user_id: str) -> dict:
    product = random.choice(PRODUCTS)
    return {
        "event_id": str(uuid.uuid4()),
        "event_type": random.choice(["page_view", "search", "add_to_cart"]),
        "event_timestamp": utc_now(),
        "user_id": user_id,
        "session_id": str(uuid.uuid4()),
        "product_id": product[0],
        "page_url": f"/products/{product[0].lower()}",
        "device_type": random.choice(["mobile", "desktop", "tablet"]),
        "referrer": random.choice(["direct", "search", "email", "social"]),
    }


def order_event(user_id: str) -> dict:
    product = random.choice(PRODUCTS)
    quantity = random.randint(1, 3)
    return {
        "event_id": str(uuid.uuid4()),
        "event_type": "order_created",
        "event_timestamp": utc_now(),
        "order_id": f"ORD-{uuid.uuid4().hex[:12].upper()}",
        "user_id": user_id,
        "product_id": product[0],
        "quantity": quantity,
        "unit_price": product[3],
        "discount_amount": round(random.choice([0, 0, 5, 10]), 2),
        "currency": "USD",
        "status": "created",
        "shipping_country": fake.country_code(),
    }


def inventory_event() -> dict:
    product = random.choice(PRODUCTS)
    on_hand = random.randint(0, 250)
    return {
        "event_id": str(uuid.uuid4()),
        "event_type": "inventory_snapshot",
        "event_timestamp": utc_now(),
        "user_id": "system",
        "product_id": product[0],
        "warehouse_id": random.choice(["WH-EAST", "WH-WEST"]),
        "quantity_on_hand": on_hand,
        "reorder_point": 25,
        "units_reserved": random.randint(0, min(20, on_hand)),
    }


def main() -> None:
    global running
    signal.signal(signal.SIGTERM, lambda *_: globals().__setitem__("running", False))
    producer = Producer(
        {"bootstrap.servers": os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"), "acks": "all"}
    )
    click_topic = os.getenv("CLICKSTREAM_TOPIC", "clickstream-events")
    order_topic = os.getenv("ORDER_TOPIC", "order-events")
    inventory_topic = os.getenv("INVENTORY_TOPIC", "inventory-events")
    rate = float(os.getenv("EVENTS_PER_SECOND", "5"))
    while running:
        user_id = f"USR-{random.randint(1, 2000):05d}"
        choice = random.random()
        event = (
            inventory_event()
            if choice < 0.05
            else order_event(user_id)
            if choice < 0.20
            else clickstream_event(user_id)
        )
        topic = (
            inventory_topic
            if event["event_type"] == "inventory_snapshot"
            else order_topic
            if event["event_type"] == "order_created"
            else click_topic
        )
        producer.produce(topic, key=user_id, value=json.dumps(event))
        producer.poll(0)
        time.sleep(1 / rate)
    producer.flush(10)


if __name__ == "__main__":
    main()
