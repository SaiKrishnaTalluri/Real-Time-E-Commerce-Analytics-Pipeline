# Deployment and operations

## AWS

```bash
cd infrastructure
terraform init
terraform plan -out=tfplan
terraform apply tfplan
aws s3 cp ../glue/bronze_to_gold.py s3://$(terraform output -raw data_lake_bucket)/scripts/
aws glue start-job-run --job-name $(terraform output -raw glue_job_name)
```

Use MSK or MSK Serverless for managed Kafka. Pass brokers through a Glue connection or secure runtime parameter; never commit secrets. For private subnets, add S3 gateway and CloudWatch interface endpoints.

## Snowflake

Run `snowflake/00_setup.sql`, inspect `DESC INTEGRATION ECOMMERCE_S3_INT`, establish the AWS trust relationship, then run scripts 01 and 02. Execute `SHOW PIPES` and add the returned notification channel to S3 event notifications. Grant consumers access only to the `ANALYTICS` schema.

## Monitoring

- Alert on Kafka consumer lag, streaming batch duration, failed Glue runs, quarantine count, and Snowpipe load errors.
- Reconcile daily order counts and net revenue between Silver, Gold, and Snowflake.
- Set CloudWatch log retention and Snowflake resource monitors.

## Recovery

Streaming checkpoints preserve offsets. For a controlled replay, stop the job, use a new checkpoint path, and write to a versioned target prefix before promotion. S3 versioning protects prior objects; Snowflake `COPY_HISTORY` identifies rejected files.

## Teardown

Empty the development bucket, then run `terraform destroy`. Drop the Snowflake database, integration, and warehouse only after confirming no shared consumers remain.
