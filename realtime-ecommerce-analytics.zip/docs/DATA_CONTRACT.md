# Event data contract

All events use UTF-8 JSON, UUID `event_id`, UTC ISO-8601 `event_timestamp`, and a stable `user_id`. Producers must treat `event_id` as idempotency key.

## Clickstream

Required: `event_id`, `event_type`, `event_timestamp`, `user_id`, `session_id`, `product_id`, `page_url`, `device_type`. Supported types: `page_view`, `search`, `add_to_cart`.

## Order

Required: common fields plus `order_id`, `quantity`, `unit_price`, `currency`, `status`. Monetary values use decimal-compatible JSON numbers and ISO 4217 currency codes. Quantity must be positive.

## Inventory

Required: common fields plus `warehouse_id`, `quantity_on_hand`, `units_reserved`, and `reorder_point`. Snapshots are emitted by the system producer; `user_id` is `system`.

## Evolution policy

New optional fields are backward compatible. Removing, renaming, or changing a field type requires a new topic/schema version. Consumers retain unknown fields in Bronze and explicitly select fields in Silver.
