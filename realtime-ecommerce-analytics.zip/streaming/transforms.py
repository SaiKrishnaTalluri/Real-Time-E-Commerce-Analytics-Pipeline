from pyspark.sql import DataFrame
from pyspark.sql import functions as F

REQUIRED = ["event_id", "event_type", "event_timestamp", "user_id", "product_id"]


def add_metadata(df: DataFrame, source_topic: str) -> DataFrame:
    return (
        df.withColumn("event_ts", F.to_timestamp("event_timestamp"))
        .withColumn("ingested_at", F.current_timestamp())
        .withColumn("source_topic", F.lit(source_topic))
        .withColumn("event_date", F.to_date("event_ts"))
    )


def valid_events(df: DataFrame) -> DataFrame:
    condition = F.col(REQUIRED[0]).isNotNull()
    for column in REQUIRED[1:]:
        condition = condition & F.col(column).isNotNull()
    return df.filter(condition & F.col("event_ts").isNotNull())


def invalid_events(df: DataFrame) -> DataFrame:
    valid = F.col(REQUIRED[0]).isNotNull()
    for column in REQUIRED[1:]:
        valid = valid & F.col(column).isNotNull()
    return df.filter(~(valid & F.col("event_ts").isNotNull())).withColumn(
        "quarantine_reason", F.lit("missing required field or invalid timestamp")
    )


def deduplicate(df: DataFrame) -> DataFrame:
    return df.withWatermark("event_ts", "10 minutes").dropDuplicates(["event_id"])
