from pyspark.sql.types import DoubleType, IntegerType, StringType, StructField, StructType

COMMON = [
    StructField("event_id", StringType()),
    StructField("event_type", StringType()),
    StructField("event_timestamp", StringType()),
    StructField("user_id", StringType()),
    StructField("product_id", StringType()),
]
CLICKSTREAM_SCHEMA = StructType(
    COMMON
    + [
        StructField("session_id", StringType()),
        StructField("page_url", StringType()),
        StructField("device_type", StringType()),
        StructField("referrer", StringType()),
    ]
)
ORDER_SCHEMA = StructType(
    COMMON
    + [
        StructField("order_id", StringType()),
        StructField("quantity", IntegerType()),
        StructField("unit_price", DoubleType()),
        StructField("discount_amount", DoubleType()),
        StructField("currency", StringType()),
        StructField("status", StringType()),
        StructField("shipping_country", StringType()),
    ]
)
INVENTORY_SCHEMA = StructType(
    COMMON
    + [
        StructField("warehouse_id", StringType()),
        StructField("quantity_on_hand", IntegerType()),
        StructField("reorder_point", IntegerType()),
        StructField("units_reserved", IntegerType()),
    ]
)
