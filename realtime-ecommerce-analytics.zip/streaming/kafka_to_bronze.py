import os

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from streaming.schemas import CLICKSTREAM_SCHEMA, INVENTORY_SCHEMA, ORDER_SCHEMA
from streaming.transforms import add_metadata, deduplicate, invalid_events, valid_events


def stream_topic(spark, brokers, topic, schema):
    raw = (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", brokers)
        .option("subscribe", topic)
        .option("startingOffsets", "earliest")
        .load()
    )
    parsed = raw.select(F.from_json(F.col("value").cast("string"), schema).alias("e")).select("e.*")
    return add_metadata(parsed, topic)


def write(df, path, checkpoint):
    return (
        df.writeStream.format("parquet")
        .outputMode("append")
        .partitionBy("event_date")
        .option("path", path)
        .option("checkpointLocation", checkpoint)
        .trigger(processingTime="30 seconds")
        .start()
    )


def main():
    spark = SparkSession.builder.appName("ecommerce-kafka-to-bronze").getOrCreate()
    brokers = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
    root = os.getenv("OUTPUT_PATH", "/tmp/lake").rstrip("/")
    checkpoints = os.getenv("CHECKPOINT_PATH", "/tmp/checkpoints").rstrip("/")
    jobs = []
    for name, topic, schema in [
        ("clickstream", os.getenv("CLICKSTREAM_TOPIC", "clickstream-events"), CLICKSTREAM_SCHEMA),
        ("orders", os.getenv("ORDER_TOPIC", "order-events"), ORDER_SCHEMA),
        ("inventory", os.getenv("INVENTORY_TOPIC", "inventory-events"), INVENTORY_SCHEMA),
    ]:
        events = stream_topic(spark, brokers, topic, schema)
        jobs.append(
            write(
                deduplicate(valid_events(events)), f"{root}/bronze/{name}", f"{checkpoints}/{name}"
            )
        )
        jobs.append(
            write(
                invalid_events(events), f"{root}/quarantine/{name}", f"{checkpoints}/{name}-invalid"
            )
        )
    spark.streams.awaitAnyTermination()


if __name__ == "__main__":
    main()
