USE DATABASE ECOMMERCE_ANALYTICS;
CREATE OR REPLACE VIEW ANALYTICS.FCT_DAILY_PRODUCT_PERFORMANCE AS
SELECT payload:event_date::DATE metric_date, payload:product_id::STRING product_id,
       payload:orders::NUMBER orders, payload:units_sold::NUMBER units_sold,
       payload:gross_revenue::NUMBER(18,2) gross_revenue, payload:net_revenue::NUMBER(18,2) net_revenue,
       payload:unique_customers::NUMBER unique_customers
FROM RAW.DAILY_PRODUCT_PERFORMANCE
QUALIFY ROW_NUMBER() OVER (PARTITION BY metric_date, product_id ORDER BY loaded_at DESC)=1;

CREATE OR REPLACE VIEW ANALYTICS.FCT_CUSTOMER_ACTIVITY AS
SELECT payload:event_date::DATE activity_date, payload:user_id::STRING user_id,
       payload:events::NUMBER events, payload:sessions::NUMBER sessions,
       payload:add_to_carts::NUMBER add_to_carts
FROM RAW.CUSTOMER_ACTIVITY
QUALIFY ROW_NUMBER() OVER (PARTITION BY activity_date, user_id ORDER BY loaded_at DESC)=1;

CREATE OR REPLACE VIEW ANALYTICS.REVENUE_KPIS AS
SELECT metric_date, SUM(net_revenue) net_revenue, SUM(orders) orders,
       DIV0(SUM(net_revenue), SUM(orders)) average_order_value, SUM(unique_customers) purchasing_customers
FROM ANALYTICS.FCT_DAILY_PRODUCT_PERFORMANCE GROUP BY metric_date;

CREATE OR REPLACE VIEW ANALYTICS.FCT_INVENTORY_TRENDS AS
SELECT payload:event_date::DATE snapshot_date, payload:product_id::STRING product_id,
       payload:warehouse_id::STRING warehouse_id, payload:min_on_hand::NUMBER min_on_hand,
       payload:max_on_hand::NUMBER max_on_hand, payload:avg_on_hand::NUMBER(18,2) avg_on_hand,
       payload:reorder_point::NUMBER reorder_point, payload:low_stock_flag::BOOLEAN low_stock_flag
FROM RAW.INVENTORY_TRENDS
QUALIFY ROW_NUMBER() OVER (PARTITION BY snapshot_date, product_id, warehouse_id ORDER BY loaded_at DESC)=1;
