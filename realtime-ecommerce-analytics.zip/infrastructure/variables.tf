variable "aws_region" {
  type    = string
  default = "us-east-1"
}
variable "project_name" {
  type    = string
  default = "ecommerce-analytics"
}
variable "environment" {
  type    = string
  default = "dev"
}
output "data_lake_bucket" { value = aws_s3_bucket.lake.id }
output "glue_job_name" { value = aws_glue_job.bronze_to_gold.name }
